class AppConfig:
    HOST = "localhost"
    PORT = 8001

def get_app_config():
    return AppConfig