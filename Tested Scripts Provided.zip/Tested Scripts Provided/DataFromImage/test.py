#test.py
from get_image_informations import get_image_informations

result = get_image_informations("image.jpg")
print('\n Here is the Output: \n',result)
