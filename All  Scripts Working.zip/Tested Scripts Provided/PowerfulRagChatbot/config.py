import os
from dotenv import load_dotenv

load_dotenv()

urls = [
    "https://lilianweng.github.io/posts/2023-06-23-agent/",
    "https://lilianweng.github.io/posts/2023-03-15-prompt-engineering/",
    "https://lilianweng.github.io/posts/2023-10-25-adv-attack-llm/",
]

openai_key = "sk-proj-MYk8lBN6u1EhkJ1djiTDT3BlbkFJ3gPxU8gk0jkQO0O7TGS9"
tavily_api_key = "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" # I added my own API key here you may generate your own later on

os.environ["TAVILY_API_KEY"] = tavily_api_key
os.environ["OPENAI_API_KEY"] = openai_key